def Test1():
	Sys.WaitBrowser('*')
	Sys.Browser('*').ToUrl('http://10.191.1.11/code/checkSI.php')